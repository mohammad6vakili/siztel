(this["webpackJsonpvuexy-react-admin-dashboard"]=this["webpackJsonpvuexy-react-admin-dashboard"]||[]).push([[22],{1536:function(a,s){}}]);
//# sourceMappingURL=22.710ea797.chunk.js.map